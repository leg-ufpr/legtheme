#' @details Trial run on RMarkdown templates
#' @importFrom rmarkdown beamer_presentation
"_PACKAGE"
